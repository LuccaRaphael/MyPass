package br.com.fiap.mypasslucca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyPassJavaApplicationTests {

    @Test
    void contextLoads() {
    }

}
