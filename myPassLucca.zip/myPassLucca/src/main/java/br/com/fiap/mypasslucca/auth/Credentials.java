package br.com.fiap.mypasslucca.auth;

public record Credentials(String username, String password) {
}
