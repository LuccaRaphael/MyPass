package br.com.fiap.mypasslucca.auth;

public record Token(String token, String type, String username) {
}
