create table if not exists users (
                                     id bigint not null auto_increment,
                                     username varchar(255),
    password varchar(255),
    primary key (id)
    );

INSERT INTO users (username, password)
VALUES
    ('lucca raphael', '$2a$12$HO/pEmlk7oKEDFxWjLRghezFGB0qw/lsUo00gWzyGdntjitl.NELa'),
    ('lucca maciel', '$2a$12$8o48CraJplX8.QCQmSHxvOAvhsBq7UQijRN53lQspf6jPxBeI7w72'),
    ('lucca fael', '$2a$12$ojLNOalSGBGuN8FPGzGYwO90vq1iioetQvAXyrX4N//bG3pjrweKK'),
    ('julia silva', '$2a$12$M8E6jJ3WkG7Qh4RPjRsmhOwz5PfAvvG4O7vJ99Hp9w5lvkLAPpDeS'),
    ('marcos alves', '$2a$12$G8H93Fz7Psz0QFiUuJ5FOeUShB3yJPzFHQY7dm4MSH/U.dC0OGI6e'),
    ('fernanda lima', '$2a$12$Y8GQjRg5bYFQmCTYpG9IuO/J1ZTnM25Zs5lkLhXBhtZqNTzG1MBuO'),
    ('pedro martins', '$2a$12$uJr71CEeK9nry0v7p6DRtOL9Z5WzL7/0OeEKI1qlJ6eM8gOqv6b.i'),
    ('ana costa', '$2a$12$Gz3dO5v7eAoIuDpUOeRyaOp/lHHyz1VuHkY5gTFSzk1ZrEOW9PId6'),
    ('ricardo pereira', '$2a$12$SvI9S4bZ8wLEFDwFgGh6tOx02bZs3JoRYD3ep62j.TLrJ42qPcbha'),
    ('beatriz rodrigues', '$2a$12$eD5vAX.4CFl1/5OT4xFE0eO9hIxqG46OMmGxgiJz3aBoPfflz8aFa'),
    ('luan oliveira', '$2a$12$DFY8KxZ0.5KzUXGcXj5qXONzeGHF4fI66ru/7j6OKXqz/4kVh6VuG'),
    ('carla santos', '$2a$12$RW/a2o8K5rLbI1d3r8CdmOk6vDi59xFh1jRXvxgLz/YYBvW1t7xAy');
